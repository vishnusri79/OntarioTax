package com.example.canada_taxing;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText incomeEditText;
    private TextView rrspLimitTextView;
    private EditText rrspContributionEditText;

    private TextView taxTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.dropdown_items, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Handle spinner selection here
                String selectedItem = parent.getItemAtPosition(position).toString();


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        SeekBar seekBar = findViewById(R.id.seekBar);
        final TextView textView = findViewById(R.id.textView9);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Update TextView with current progress value
                textView.setText(String.valueOf(progress));


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Called when user starts touching the SeekBar
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Called when user stops touching the SeekBar
            }
        });

        // Find views by their IDs
        incomeEditText = findViewById(R.id.editTextText8);
        rrspLimitTextView = findViewById(R.id.textView11);
        rrspContributionEditText = findViewById(R.id.editTextText9);
        incomeEditText = findViewById(R.id.editTextText8);

        taxTextView = findViewById(R.id.textView10);

        Button goButton = findViewById(R.id.button3);
        goButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the income entered by the user
                String incomeString = incomeEditText.getText().toString();
                if (incomeString.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter income", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Convert the income to double
                double income = Double.parseDouble(incomeString);

                // Calculate RRSP limit (18% of the income)
                double rrspLimit = income * 0.18;

                // Update the TextView with the calculated RRSP limit
                rrspLimitTextView.setText("RRSP Limit: $" + rrspLimit);
            }
        });

        Button refreshButton = findViewById(R.id.button);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear all fields
                incomeEditText.setText("");
                rrspLimitTextView.setText("");
                rrspContributionEditText.setText("");
                taxTextView.setText("Tax: $0");
            }
        });

        Button submitButton = findViewById(R.id.button2);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the RRSP limit
                String rrspLimitString = rrspLimitTextView.getText().toString();
                double rrspLimit = Double.parseDouble(rrspLimitString.substring(rrspLimitString.indexOf("$") + 1));

                // Get the RRSP contribution entered by the user
                String rrspContributionString = rrspContributionEditText.getText().toString();
                if (rrspContributionString.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter RRSP contribution", Toast.LENGTH_SHORT).show();
                    return;
                }
                double rrspContribution = Double.parseDouble(rrspContributionString);

                // Check if RRSP contribution exceeds RRSP limit
                if (rrspContribution > rrspLimit) {
                    // Show alert to the user
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("You cannot contribute more than the limit")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Close the dialog
                                    dialog.dismiss();
                                }
                            });
                    builder.create().show();
                    return;
                }



                submitButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        calculateTax();
                    }



                    public void calculateTax() {

                        String incomeString = incomeEditText.getText().toString().trim();
                        String contributionString = rrspContributionEditText.getText().toString().trim();

                        // Validate input
                        if (incomeString.isEmpty() || contributionString.isEmpty()) {
                            Toast.makeText(MainActivity.this, "Please enter both income and contribution", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        double income = Double.parseDouble(incomeString);
                        double contribution = Double.parseDouble(contributionString);
                        double taxableIncome = income - contribution;

                        // Determine tax percentage based on taxable income
                        double taxPercentage;
                        if (taxableIncome <= 51446) {
                            taxPercentage = 20.05;
                        } else if (taxableIncome <= 55867) {
                            taxPercentage = 24;
                        } else if (taxableIncome <= 90599) {
                            taxPercentage = 29.65;
                        } else if (taxableIncome <= 102894) {
                            taxPercentage = 31.48;
                        } else if (taxableIncome <= 106732) {
                            taxPercentage = 33.89;
                        } else if (taxableIncome <= 111733) {
                            taxPercentage = 37.91;
                        } else if (taxableIncome <= 150000) {
                            taxPercentage = 43.41;
                        } else if (taxableIncome <= 173205) {
                            taxPercentage = 44.97;
                        } else if (taxableIncome <= 220000) {
                            taxPercentage = 48.29;
                        } else if (taxableIncome <= 246752) {
                            taxPercentage = 49.85;
                        } else {
                            taxPercentage = 53.53;
                        }

                        // Calculate tax amount
                        double taxAmount = (taxableIncome * taxPercentage) / 100;

                        // Display tax amount
                        taxTextView.setText("Tax: $" + taxAmount);
                    }
                });
            }
        });
    }
}